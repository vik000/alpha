window.jQuery = window.$ = require(‘jquery’);
console.log($);
var bootstrap = require('bootstrap/dist/js/bootstrap'); //Esto lo ponemos cuando instalemos bootstrap (que tiene que ser por npm). Con esto ya debería ir.
console.log("hi");
